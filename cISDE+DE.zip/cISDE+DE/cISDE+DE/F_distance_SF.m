function DistanceValue = F_distance_SF(FunctionValue,CV,M)

    [N,M] = size(FunctionValue);
    PopObj = FunctionValue;
%%  sumof OBJECTIVE
      
    fmax   = repmat(max(PopObj,[],1),N,1);
    fmin   = repmat(min(PopObj,[],1),N,1);
    PopObj = (PopObj-fmin)./(fmax-fmin); 
%    kt = rand;
%     if kt <0.3
%         w = repmat([1 0],N,1);
%     elseif kt>=0.3 && kt <0.6
%         w = (1/M)*repmat(ones(1,M),N,1);
%     else
%        w = repmat([0 1],N,1);
%   end
    fpr    = mean(PopObj,2);
    [~,rank] = sortrows([CV,fpr],[1,2]);
    
    

%     alpha             = zeros(1,M);
%     
%     for k =1:M
%          alpha(1,k)= alpha_sort(PopObj(:,k),CV);
%     end
%     
%     PopObj = PopObj + repmat(alpha,N,1).*repmat(CV,1,M);
%     
%     fpr    = mean(PopObj,2);
%     [~,rank] = sort(fpr);

   


 %%%%%%%%%%%%% % SDE with Sum of Objectives  %%%%%%%%%%%%%%%%%%%%
%     DistanceValue = zeros(1,N);                             
%     
% 
%     for j = 2 : N
% 
%         SFunctionValue = max(PopObj(rank(1:j-1),:),repmat(PopObj(rank(j),:),(j-1),1));
%         
%         Distance = inf(1,j-1);
%             
%         for i = 1 : (j-1)
%             Distance(i) = norm(SFunctionValue(i,:)-PopObj(rank(j),:))/M;
%         end
%            
%         Distance = min(Distance);
%                
%         DistanceValue(rank(j)) = exp(-Distance);
% 
%          
%     end
    
%     SCV     = (CV-repmat(min(CV),length(CV),1))./(repmat(max(CV),length(CV),1)-repmat(min(CV),length(CV),1));
%     DistanceValue    = DistanceValue+SCV'; 
%     KK = length(find(CV==0))/N;
%     flag
%     if flag == 1 && KK <=0.5
%        PT = find(CV==0); 
%        DistanceValue(PT) = 0;
%     end
%     if flag == 1 && KK > 0.5
%         PT = find(CV~=0);
%         DistanceValue(PT) = 1;
%     end
%     flag
%     if flag == 1
%         PT = find(CV~=0);
%         DistanceValue(PT) = DistanceValue(PT)+1;
%     end
    

    DistanceValue = zeros(1,N);                             
    

    for j = 2 : N

        SFunctionValue = max(PopObj(rank(1:j-1),:),repmat(PopObj(rank(j),:),(j-1),1));
        
        Distance = inf(1,j-1);
            
        for i = 1 : (j-1)
            Distance(i) = norm(SFunctionValue(i,:)-PopObj(rank(j),:))/M;
        end
           
        Distance = [Distance,ones(1,N-1-length(Distance))];
               
      %  DistanceValue(rank(j)) = sum(exp(-max(Distance))+exp(-min(Distance)))+length(find(Distance==0))/N;
      DistanceValue(rank(j)) = exp(-min(Distance))+length(find(Distance==0))/N;
        %DistanceValue(rank(j)) = exp(-min(Distance))++length(find(Distance==0))/N+sum(sum(PopObj(rank(find(Distance==0)),:),2),1)/sum(fpr,1);
    end
  
