classdef cISDE_DE < ALGORITHM
% % <2025> <multi/many> <real/integer/label/binary/permutation> <constrained/none>


    methods
        function main(Algorithm,Problem)

    Population          =   Problem.Initialization();
    CV                  =   sum(max(0,Population.cons),2);
    DistanceValue       =   F_distance_SF(Population.objs,CV,Problem.M);
    index = zeros(Problem.N,1); % enforcing DE
    % Uncomment for SDC15
    % PF                 = Problem.optimum;  
    % [PF,~,~]           = PFSelection(PF,100);
    igd=IGD(Population,Problem.PF); %For SDC 15, change Problme. PF to PF
    cv=sum(CV)/Problem.N;
    i=1;

   

    %% Optimization
    while  Algorithm.NotTerminated(Population)
       
        Offspring = AdapativeOffspring(Population,Problem,DistanceValue,index);
        Population         = [Population,Offspring];
        CV                 = sum(max(0,Population.cons),2);
        DistanceValue      = F_distance_SF(Population.objs,CV,Problem.M);
        [~,rank]           = sort(DistanceValue,'ascend'); 
        Population         = Population(rank(1:Problem.N)); 
        DistanceValue      = DistanceValue(rank(1:Problem.N));  

        

         if mod(Problem.FE,200)==0
                    igd(i+1)=IGD(Population,Problem.PF); %For SDC 15, change Problme. PF to PF
                    CV = sum(max(0,Population.cons),2);  
                    cv(i+1)=sum(CV)/Problem.N;
                    i=i+1;
        end  
        if Problem.FE >= Problem.maxFE
            %Population = arch;
            problemName = class(Algorithm.pro);
            timestamp = datestr(now, 'yyyymmdd_HHMMSSFFF');
            AlgoName = class(Algorithm);
            folderPath = fullfile('results', AlgoName, problemName);
            % Create folder if it doesn't exist
            if ~exist(folderPath, 'dir')
                mkdir(folderPath);
            end
            filename = sprintf('%s_%s_%s.mat', AlgoName,problemName, timestamp);
            fullPath = fullfile(folderPath, filename);
            % Save to file
            save(fullPath, 'igd', 'cv');
        end

        end
    end
    end 
end