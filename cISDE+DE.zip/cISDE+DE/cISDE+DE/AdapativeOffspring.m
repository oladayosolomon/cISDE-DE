function Off = AdapativeOffspring(TPop,Problem,DistanceValue,ind)


   Off     = [];    
   OB      = TPop.objs;
   CV      = TPop.cons; 
  

    for i = 1 : Problem.N  
            
         if ind == 1
           MatingPool =zeros(1,2);
           MatingPool(1) = i;
           Parent1   = randi(Problem.N,1,1);
           Parent2   = randi(Problem.N,1,1);
            if DistanceValue(Parent1) < DistanceValue(Parent2)
              MatingPool(2) = Parent1;
            elseif DistanceValue(Parent1) > DistanceValue(Parent2)
              MatingPool(2) = Parent2;
            else
             if rand< 0.5
                MatingPool(2) = Parent1;
             else
                MatingPool(2) = Parent2;
             end
           end
      
           Offspring = OperatorGA(Problem,Tpop(MatingPool));

         else   
           B = max(OB,repmat(OB(i,:),Problem.N,1));
           Distance = sum(abs(B-repmat(OB(i,:),Problem.N,1)),2);
           T = ceil(Problem.N/5); % size of neighborhood
           [~,B] = sort(Distance);
           KT = randperm(T);
           P(2) = B(KT(1));
           P(3) = B(KT(2));

           Offspring   = OperatorDE(Problem, TPop(i),TPop(P(2)),TPop(P(3)),{1,0.5,1,20});
           
         end 
         Off          = [Off,Offspring];
        
    end  
end